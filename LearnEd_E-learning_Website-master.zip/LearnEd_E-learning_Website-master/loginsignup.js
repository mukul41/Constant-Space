
  // // Import the functions you need from the SDKs you need
  // import { initializeApp } from "https://www.gstatic.com/firebasejs/10.1.0/firebase-app.js";
  // import { getAnalytics } from "https://www.gstatic.com/firebasejs/10.1.0/firebase-analytics.js";
  // // TODO: Add SDKs for Firebase products that you want to use
  // // https://firebase.google.com/docs/web/setup#available-libraries

  // // Your web app's Firebase configuration
  // // For Firebase JS SDK v7.20.0 and later, measurementId is optional
  // const firebaseConfig = {
  //   apiKey: "AIzaSyC3x5rke_7OPYbgRg7NxBOsebhp_I7wGr0",
  //   authDomain: "smart-learning-79d7d.firebaseapp.com",
  //   projectId: "smart-learning-79d7d",
  //   storageBucket: "smart-learning-79d7d.appspot.com",
  //   messagingSenderId: "25843180814",
  //   appId: "1:25843180814:web:b0fdc1d9d7fdad5d6de35f",
  //   measurementId: "G-BDEEK7YN9M"
  // };

  // // Initialize Firebase
  // const app = initializeApp(firebaseConfig);
  // const analytics = getAnalytics(app);



 // import { getAuth, createUserWithEmailAndPassword } from "firebase/auth";

  // var age = document.getElementById("#name");
  // console.log(age);

let register=document.getElementById("btnSubmit");
let name=document.getElementById("name").value;
console.log(name);
let email=document.getElementById("email");
let password=document.getElementById("password");

//let username=name.value;
register.addEventListener("click", signup);
function signup(event) {
    console.log(age);
};

  createUserWithEmailAndPassword(auth, email, password)
  .then((userCredential) => {
    // Signed in 
    const user = userCredential.user;
    // ...
  })
  .catch((error) => {
    const errorCode = error.code;
    const errorMessage = error.message;
    // ..
  })


